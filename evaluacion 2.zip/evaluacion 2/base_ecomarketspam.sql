SELECT * FROM base_ecomarketspa.producto;
insert into base_ecomarketspa.producto (nombre, descripcion, precio) values ('estuches ecomas', 'producto ecologico hecho de materiales renovable', 6500);
insert into base_ecomarketspa.producto (nombre, descripcion, precio) values ('bolsa plus ecomas', 'producto ecologico hecho de materiales renovable', 9990);